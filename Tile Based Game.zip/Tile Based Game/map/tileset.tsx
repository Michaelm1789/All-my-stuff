<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="tileset" tilewidth="64" tileheight="64" tilecount="64" columns="8">
 <grid orientation="orthogonal" width="32" height="32"/>
 <image source="Tileset.png" trans="000000" width="512" height="512"/>
</tileset>
