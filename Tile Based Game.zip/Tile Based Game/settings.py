import pygame as pg
vec = pg.math.Vector2
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
DARKGREY = (40, 40, 40)
LIGHTGREY = (100, 100, 100)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
YELLOW = (255, 255, 0)


# game settings
WIDTH = 1024   # 16 * 64 or 32 * 32 or 64 * 16
HEIGHT = 768  # 16 * 48 or 32 * 24 or 64 * 12
FPS = 60
TITLE = "Tilemap Demo"
BGCOLOR = DARKGREY

TILESIZE = 64
GRIDWIDTH = WIDTH / TILESIZE
GRIDHEIGHT = HEIGHT / TILESIZE

WALL_IMG = 'wall.png'
# Player settings
PLAYER_HEALTH = 100
PLAYER_SPEED = 280.0
PLAYER_ROT_SPEED = 200
PLAYER_IMG = 'player.png'
PLAYER_HIT_RECT = pg.Rect(0, 0, 35, 35)
BARREL_OFFSET = vec(25, 10)

# weapons settings

BULLET_IMG = 'bullet.png'
WEAPONS = {}
WEAPONS['pistol'] = {'bullet_speed': 500,
                     'bullet_lifetime': 1000,
                     'rate': 250,
                     'kickback': 50,
                     'spread': 5,
                     'damage': 15,
                     'bullet_size': 'lg',
                     'bullet_count': 1}

WEAPONS['shotgun'] = {'bullet_speed': 400,
                     'bullet_lifetime': 700,
                     'rate': 800,
                     'kickback': 100,
                     'spread': 20,
                     'damage': 7,
                     'bullet_size': 'sm',
                     'bullet_count': 12}

BULLET_SPEED = 500
BULLET_LIFETIME = 1000
BULLET_RATE = 150
KICKBACK = 200
GUN_SPREAD = 5
BULLET_DAMAGE = 10

MOB_IMG = "triangle.png"
MOB_SPEEDS = [150, 100, 80, 125]
MOB_HIT_RECT = pg.Rect(0, 0, 30, 30)
MOB_HEALTH = 100
MOB_DAMAGE = 10
MOB_KNOCKBACK = 20
AVOID_RADIUS = 50
DETECT_RADIUS = 400

#Effects
MUZZLE_FLASHES = ['whitePuff15.png', 'whitePuff16.png', 'whitePuff17.png',
                  'whitePuff18.png']
                  
FLASH_DURATION = 40
DAMAGE_ALPHA = [i for i in range(1, 255, 25)]
NIGHT_COLOR = (20, 20, 20)
LIGHT_RADIUS = (500, 500)
LIGHT_MASK = "light_350_med.png"




WALL_LAYER = 1
PLAYER_LAYER = 2
BULLET_LAYER = 3
MOB_LAYER = 2
EFFECTS_LAYER = 4

# items

ITEM_IMAGES = {'health': 'health_pack.png',
               'shotgun': 'shotgun.png'}
HEALTH_PACK_AMOUNT = 20
BOB_RANGE = 15
BOB_SPEED = .6

#sounds

BG_MUSIC = 'crashedship.ogg'
PLAYER_HIT_SOUNDS = ['hurt1.wav', 'hurt2.wav']
ENEMY_SOUNDS = ['enemy1.wav', 'enemy2.wav']
ENEMY_HIT_SOUNDS = ['enemyhurt1.wav', 'enemyhurt2.wav']
WEAPON_SOUNDS = {'pistol': ['shoot1.wav'],
                 'shotgun': ['shoot1.wav']}

EFFECTS_SOUNDS = {'level_start' : 'level_start.wav',
                  'health_up' : 'health_up.wav',
                  'gun_pickup': 'gun_pickup.wav'}
